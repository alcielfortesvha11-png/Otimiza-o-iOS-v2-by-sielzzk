
import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @State private var password = ""
    @State private var authenticated = false
    @State private var showingFolderPicker = false
    @State private var status = "Aguardando autenticação"
    @State private var isWorking = false
    @State private var progress = 0.0

    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.035, blue: 0.045)
                .ignoresSafeArea()

            VStack(spacing: 22) {
                Spacer()

                ZStack {
                    Circle()
                        .fill(Color.red.opacity(0.12))
                        .frame(width: 104, height: 104)

                    Image(systemName: "bolt.fill")
                        .font(.system(size: 42, weight: .bold))
                        .foregroundStyle(.red)
                }

                Text("OTIMIZAÇÃO")
                    .font(.system(size: 27, weight: .black, design: .rounded))
                    .foregroundStyle(.white)

                Text("iOS v2 by sielzzk")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))

                if !authenticated {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("SENHA DE ACESSO")
                            .font(.system(size: 11, weight: .bold))
                            .tracking(1.5)
                            .foregroundStyle(.white.opacity(0.55))

                        SecureField("Digite a senha", text: $password)
                            .textContentType(.password)
                            .padding(16)
                            .background(Color.white.opacity(0.07))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .overlay {
                                RoundedRectangle(cornerRadius: 14)
                                    .stroke(Color.white.opacity(0.1))
                            }
                            .foregroundStyle(.white)

                        Button {
                            if password == "123" {
                                authenticated = true
                                status = "Acesso autorizado"
                            } else {
                                status = "Senha incorreta"
                            }
                        } label: {
                            Text("ENTRAR")
                                .font(.system(size: 14, weight: .heavy))
                                .tracking(1)
                                .frame(maxWidth: .infinity)
                                .padding(17)
                                .background(Color.red)
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                    }
                    .padding(.top, 18)

                } else {
                    Button {
                        showingFolderPicker = true
                    } label: {
                        HStack(spacing: 10) {
                            if isWorking {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Image(systemName: "arrow.down.to.line")
                            }

                            Text(isWorking
                                 ? "COPIANDO ARQUIVOS..."
                                 : "INJETAR OTIMIZAÇÃO")
                                .font(.system(size: 14, weight: .heavy))
                                .tracking(0.7)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(19)
                        .background(Color.red)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .shadow(color: .red.opacity(0.25), radius: 16, y: 6)
                    }
                    .disabled(isWorking)
                    .padding(.top, 20)

                    if isWorking {
                        ProgressView(value: progress)
                            .tint(.red)

                        Text("\(Int(progress * 100))%")
                            .foregroundStyle(.white.opacity(0.7))
                            .font(.system(size: 12, weight: .bold))
                    }
                }

                Text(status)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(
                        status.contains("incorreta") ||
                        status.contains("Erro") ? .orange :
                        .white.opacity(0.65)
                    )
                    .multilineTextAlignment(.center)
                    .padding(.top, 8)

                Spacer()

                Text("SIELZZK • iOS")
                    .font(.system(size: 10, weight: .bold))
                    .tracking(2)
                    .foregroundStyle(.white.opacity(0.25))
            }
            .padding(.horizontal, 28)
            .frame(maxWidth: 430)
        }
        .preferredColorScheme(.dark)

        .fileImporter(
            isPresented: $showingFolderPicker,
            allowedContentTypes: [.folder],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let folder = urls.first else {
                    status = "Nenhuma pasta selecionada"
                    return
                }

                copyOptimizationFiles(to: folder)

            case .failure(let error):
                status = "Erro ao selecionar pasta: \(error.localizedDescription)"
            }
        }
    }

    private func copyOptimizationFiles(to folder: URL) {
        guard !isWorking else { return }

        isWorking = true
        progress = 0
        status = "Preparando arquivos..."

        Task { @MainActor in
            defer {
                isWorking = false
            }

            do {
                let source = Bundle.main.resourceURL?
                    .appendingPathComponent(
                        "OptimizationFiles",
                        isDirectory: true
                    )

                guard let source = source else {
                    throw CopyError.sourceNotFound
                }

                let accessed = folder.startAccessingSecurityScopedResource()

                guard accessed else {
                    throw CopyError.permissionDenied
                }

                defer {
                    folder.stopAccessingSecurityScopedResource()
                }

                var isDirectory: ObjCBool = false

                guard FileManager.default.fileExists(
                    atPath: source.path,
                    isDirectory: &isDirectory
                ), isDirectory.boolValue else {
                    throw CopyError.sourceNotFound
                }

                let items = try FileManager.default.contentsOfDirectory(
                    at: source,
                    includingPropertiesForKeys: [.isRegularFileKey],
                    options: [.skipsHiddenFiles]
                )

                let files = try items.filter {
                    let values = try $0.resourceValues(
                        forKeys: [.isRegularFileKey]
                    )
                    return values.isRegularFile == true
                }

                guard !files.isEmpty else {
                    throw CopyError.noFiles
                }

                var copied = 0
                var skipped = 0

                for (index, item) in files.enumerated() {
                    let destination = folder.appendingPathComponent(
                        item.lastPathComponent
                    )

                    if FileManager.default.fileExists(
                        atPath: destination.path
                    ) {
                        skipped += 1
                    } else {
                        try FileManager.default.copyItem(
                            at: item,
                            to: destination
                        )
                        copied += 1
                    }

                    progress = Double(index + 1) / Double(files.count)

                    try await Task.sleep(
                        nanoseconds: 100_000_000
                    )
                }

                if copied > 0 && skipped == 0 {
                    status = "\(copied) arquivos copiados com sucesso!"
                } else if copied > 0 {
                    status = "\(copied) copiados; \(skipped) já existiam."
                } else {
                    status = "Todos os arquivos já existiam na pasta."
                }

            } catch {
                status = "Erro: \(error.localizedDescription)"
            }
        }
    }
}

enum CopyError: LocalizedError {
    case sourceNotFound
    case permissionDenied
    case noFiles

    var errorDescription: String? {
        switch self {
        case .sourceNotFound:
            return "Arquivos OptimizationFiles não encontrados no aplicativo."
        case .permissionDenied:
            return "O iOS não concedeu acesso à pasta selecionada."
        case .noFiles:
            return "Nenhum arquivo encontrado para copiar."
        }
    }
}
