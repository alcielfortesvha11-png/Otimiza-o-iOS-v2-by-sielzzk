import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @State private var password = ""
    @State private var authenticated = false
    @State private var showingFolderPicker = false
    @State private var status = "Aguardando autenticação"
    @State private var isWorking = false

    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.035, blue: 0.045).ignoresSafeArea()
            VStack(spacing: 22) {
                Spacer()
                ZStack {
                    Circle().fill(Color.red.opacity(0.12)).frame(width: 104, height: 104)
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 42, weight: .bold))
                        .foregroundStyle(.red)
                }
                Text("OTIMIZAÇÃO")
                    .font(.system(size: 27, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("iOS v2 by sielzzk")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))

                if !authenticated {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("SENHA DE ACESSO")
                            .font(.system(size: 11, weight: .bold))
                            .tracking(1.5)
                            .foregroundStyle(.white.opacity(0.55))
                        SecureField("Digite a senha", text: $password)
                            .textContentType(.password)
                            .padding(16)
                            .background(Color.white.opacity(0.07))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.1)))
                            .foregroundStyle(.white)
                        Button {
                            if password == "123" {
                                authenticated = true
                                status = "Acesso autorizado"
                            } else {
                                status = "Senha incorreta"
                            }
                        } label: {
                            Text("ENTRAR")
                                .font(.system(size: 14, weight: .heavy))
                                .tracking(1)
                                .frame(maxWidth: .infinity)
                                .padding(17)
                                .background(Color.red)
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                    }
                    .padding(.top, 18)
                } else {
                    Button {
                        showingFolderPicker = true
                    } label: {
                        HStack(spacing: 10) {
                            if isWorking { ProgressView().tint(.white) }
                            else { Image(systemName: "arrow.down.to.line") }
                            Text("INJETAR OTIMIZAÇÃO")
                                .font(.system(size: 14, weight: .heavy))
                                .tracking(0.7)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(19)
                        .background(Color.red)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .shadow(color: .red.opacity(0.25), radius: 16, y: 6)
                    }
                    .disabled(isWorking)
                    .padding(.top, 20)
                }

                Text(status)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(status.contains("incorreta") ? .orange : .white.opacity(0.55))
                    .multilineTextAlignment(.center)
                    .padding(.top, 8)
                Spacer()
                Text("SIELZZK • iOS")
                    .font(.system(size: 10, weight: .bold))
                    .tracking(2)
                    .foregroundStyle(.white.opacity(0.25))
            }
            .padding(.horizontal, 28)
            .frame(maxWidth: 430)
        }
        .preferredColorScheme(.dark)
        .fileImporter(isPresented: $showingFolderPicker, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let folder = urls.first else { return }
                copyOptimizationFiles(to: folder)
            case .failure:
                status = "Seleção de pasta cancelada"
            }
        }
    }

    private func copyOptimizationFiles(to folder: URL) {
        guard let source = Bundle.main.resourceURL?.appendingPathComponent("OptimizationFiles", isDirectory: true) else {
            status = "Arquivos do projeto não encontrados"
            return
        }
        let accessed = folder.startAccessingSecurityScopedResource()
        defer { if accessed { folder.stopAccessingSecurityScopedResource() } }

        do {
            let items = try FileManager.default.contentsOfDirectory(at: source, includingPropertiesForKeys: nil)
            guard !items.isEmpty else {
                status = "Nenhum arquivo de otimização encontrado"
                return
            }
            for item in items {
                let destination = folder.appendingPathComponent(item.lastPathComponent)
                if FileManager.default.fileExists(atPath: destination.path) {
                    try FileManager.default.removeItem(at: destination)
                }
                try FileManager.default.copyItem(at: item, to: destination)
            }
            status = "\(items.count) arquivos copiados para a pasta selecionada"
        } catch {
            status = "Não foi possível copiar: \(error.localizedDescription)"
        }
    }
}
