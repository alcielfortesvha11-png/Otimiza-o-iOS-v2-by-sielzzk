import SwiftUI

@main
struct OtimizacaoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
