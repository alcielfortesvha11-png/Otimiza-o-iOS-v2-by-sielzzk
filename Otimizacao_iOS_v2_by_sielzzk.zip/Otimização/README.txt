OTIMIZAÇÃO PARA iOS v2 by sielzzk

Conteúdo:
- Projeto-fonte SwiftUI para Xcode
- Os 5 arquivos recebidos no ZIP original, incluídos como recursos do app
- Tela de login com senha local 123
- Um único botão após o login: INJETAR OTIMIZAÇÃO

Como abrir:
1. No Mac, abra o arquivo project.yml com XcodeGen instalado ou gere o projeto conforme abaixo.
2. Instale XcodeGen: brew install xcodegen
3. Entre nesta pasta no Terminal e execute: xcodegen generate
4. Abra Otimizacao.xcodeproj no Xcode.
5. Selecione sua equipe de assinatura (Signing & Capabilities), um Bundle Identifier exclusivo e um dispositivo iOS.
6. Compile e assine pelo Xcode.

IMPORTANTE SOBRE O iOS:
O botão abre o seletor de pastas do iOS e copia os arquivos para uma pasta que o usuário possa selecionar.
O iOS normalmente não permite que um app comum acesse diretamente a pasta privada de dados de outro app,
incluindo com.dts.freefiremax. Portanto, a pasta do Free Fire MAX pode não aparecer no seletor e a cópia
direta para o sandbox do jogo não é possível por este método. O projeto não contorna essa proteção.
